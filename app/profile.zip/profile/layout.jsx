import ProfileShell from "./ProfileShell";

export default function ProfileLayout({ children }) {
  return <ProfileShell>{children}</ProfileShell>;
}
